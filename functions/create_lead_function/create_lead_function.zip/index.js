﻿const nodemailer = require('nodemailer');

// Rate limiting storage
const rateLimitMap = new Map();
const RATE_LIMIT_MAX = 3;
const RATE_LIMIT_WINDOW = 3600000; // 1 hour

// Verify reCAPTCHA
async function verifyRecaptcha(token, secretKey) {
    try {
        const response = await fetch('https://www.google.com/recaptcha/api/siteverify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `secret=${secretKey}&response=${token}`,
        });
        const data = await response.json();
        return data.success && data.score >= 0.5;
    } catch (error) {
        console.error('reCAPTCHA error:', error);
        return false;
    }
}

// Check rate limit
function checkRateLimit(ip) {
    const now = Date.now();
    const userLimit = rateLimitMap.get(ip);

    if (userLimit && now > userLimit.resetTime) {
        rateLimitMap.delete(ip);
    }

    const current = rateLimitMap.get(ip);

    if (!current) {
        rateLimitMap.set(ip, { count: 1, resetTime: now + RATE_LIMIT_WINDOW });
        return { allowed: true, remaining: RATE_LIMIT_MAX - 1 };
    }

    if (current.count >= RATE_LIMIT_MAX) {
        return { allowed: false, remaining: 0 };
    }

    current.count += 1;
    return { allowed: true, remaining: RATE_LIMIT_MAX - current.count };
}

// Main handler
module.exports = async (req, res) => {
    try {
        console.log('Function started');
        console.log('Request method:', req.method);
        console.log('Request body:', JSON.stringify(req.body));

        // Set CORS headers
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

        // Handle preflight
        if (req.method === 'OPTIONS') {
            console.log('Handling preflight request');
            res.status(200).send();
            return;
        }

        // Parse request body
        const requestBody = req.body || {};
        const { name, email, phone, company, service, budget, message, recaptchaToken } = requestBody;

        console.log('Received form submission from:', email);

        // Get client IP
        const clientIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim() ||
            req.headers['x-real-ip'] ||
            req.ip ||
            'unknown';

        // Validate required fields
        if (!name || !email || !service || !message) {
            console.error('Missing required fields');
            res.status(400).send({
                success: false,
                error: 'Missing required fields: name, email, service, and message are required'
            });
            return;
        }

        // Verify reCAPTCHA
        if (!recaptchaToken) {
            console.error('Missing reCAPTCHA token');
            res.status(400).send({
                success: false,
                error: 'reCAPTCHA verification required'
            });
            return;
        }

        // Get secret key from environment
        const recaptchaSecret = process.env.RECAPTCHA_SECRET_KEY;
        if (!recaptchaSecret) {
            console.error('RECAPTCHA_SECRET_KEY not configured');
            res.status(500).send({
                success: false,
                error: 'Server configuration error'
            });
            return;
        }

        console.log('Verifying reCAPTCHA...');
        const isHuman = await verifyRecaptcha(recaptchaToken, recaptchaSecret);

        if (!isHuman) {
            console.error('reCAPTCHA verification failed');
            res.status(403).send({
                success: false,
                error: 'reCAPTCHA verification failed. Please try again.'
            });
            return;
        }

        console.log('reCAPTCHA verified successfully');

        // Check rate limit
        const rateLimit = checkRateLimit(clientIp);
        if (!rateLimit.allowed) {
            console.error('Rate limit exceeded for IP:', clientIp);
            res.status(429).send({
                success: false,
                error: 'Too many requests. Please try again in an hour.'
            });
            return;
        }

        console.log('Rate limit check passed. Remaining:', rateLimit.remaining);

        // Check Gmail credentials
        if (!process.env.GMAIL_USER || !process.env.GMAIL_APP_PASSWORD) {
            console.error('Gmail credentials not configured');
            res.status(500).send({
                success: false,
                error: 'Email configuration error'
            });
            return;
        }

        console.log('Configuring email transporter...');
        const transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: process.env.GMAIL_USER,
                pass: process.env.GMAIL_APP_PASSWORD,
            },
        });

        // Create email HTML
        const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { 
            font-family: 'Segoe UI', Arial, sans-serif; 
            line-height: 1.6; 
            color: #333; 
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
          }
          .container { 
            max-width: 600px; 
            margin: 20px auto; 
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
          }
          .header { 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
            color: white; 
            padding: 40px 30px; 
            text-align: center;
          }
          .header h1 {
            margin: 0;
            font-size: 28px;
          }
          .header p {
            margin: 10px 0 0 0;
            opacity: 0.9;
          }
          .content { 
            padding: 30px;
          }
          .field { 
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 1px solid #f0f0f0;
          }
          .field:last-child {
            border-bottom: none;
          }
          .label { 
            font-weight: 600; 
            color: #667eea; 
            display: block; 
            margin-bottom: 8px;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          }
          .value { 
            color: #333;
            font-size: 15px;
            word-wrap: break-word;
          }
          .value a {
            color: #667eea;
            text-decoration: none;
          }
          .message-box {
            background: #f9f9f9;
            padding: 15px;
            border-radius: 8px;
            border-left: 4px solid #667eea;
            margin-top: 8px;
          }
          .footer { 
            text-align: center; 
            padding: 20px;
            background: #f9f9f9;
            color: #666; 
            font-size: 13px;
          }
          .badge {
            display: inline-block;
            background: #667eea;
            color: white;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            margin-top: 5px;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🎉 New Lead from Contact Form</h1>
            <p>Sangani Group Website</p>
          </div>
          <div class="content">
            <div class="field">
              <span class="label">👤 Full Name</span>
              <div class="value">${name}</div>
            </div>
            
            <div class="field">
              <span class="label">📧 Email Address</span>
              <div class="value"><a href="mailto:${email}">${email}</a></div>
            </div>
            
            ${phone ? `
            <div class="field">
              <span class="label">📱 Phone Number</span>
              <div class="value">${phone}</div>
            </div>
            ` : ''}
            
            ${company ? `
            <div class="field">
              <span class="label">🏢 Company Name</span>
              <div class="value">${company}</div>
            </div>
            ` : ''}
            
            <div class="field">
              <span class="label">🛠️ Service Required</span>
              <div class="value"><span class="badge">${service}</span></div>
            </div>
            
            ${budget ? `
            <div class="field">
              <span class="label">💰 Estimated Budget</span>
              <div class="value">${budget}</div>
            </div>
            ` : ''}
            
            <div class="field">
              <span class="label">💬 Project Details</span>
              <div class="message-box">${message.replace(/\n/g, '<br>')}</div>
            </div>
            
            <div class="field">
              <span class="label">🌐 Client IP</span>
              <div class="value">${clientIp}</div>
            </div>
            
            <div class="field">
              <span class="label">📅 Submission Time</span>
              <div class="value">${new Date().toLocaleString('en-IN', {
            timeZone: 'Asia/Kolkata',
            dateStyle: 'full',
            timeStyle: 'long'
        })}</div>
            </div>
          </div>
          <div class="footer">
            <p><strong>Sangani Group</strong> - Foundations of Innovation</p>
            <p>This email was sent from sanganigroup.in contact form</p>
            <p>Remaining requests from this IP: ${rateLimit.remaining} of ${RATE_LIMIT_MAX}</p>
          </div>
        </div>
      </body>
      </html>
    `;

        // Send email
        console.log('Sending email to:', process.env.RECIPIENT_EMAIL);
        await transporter.sendMail({
            from: `"Sangani Group Website" <${process.env.GMAIL_USER}>`,
            to: process.env.RECIPIENT_EMAIL || 'info@sanganigroup.in',
            replyTo: email,
            subject: `🔔 New Lead: ${service} - ${name}`,
            html: htmlContent,
            text: `
New Lead from Contact Form

Name: ${name}
Email: ${email}
Phone: ${phone || 'Not provided'}
Company: ${company || 'Not provided'}
Service: ${service}
Budget: ${budget || 'Not specified'}

Message:
${message}

Client IP: ${clientIp}
Submitted: ${new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' })}
      `.trim(),
        });

        console.log('Email sent successfully!');

        // Success response
        res.status(200).send({
            success: true,
            message: 'Thank you! Your message has been sent successfully. We will contact you soon.'
        });

    } catch (error) {
        console.error('Function error:', error);
        console.error('Error stack:', error.stack);

        res.status(500).send({
            success: false,
            error: 'Failed to send message. Please try again or contact us directly at info@sanganigroup.in',
            details: error.message
        });
    }
};